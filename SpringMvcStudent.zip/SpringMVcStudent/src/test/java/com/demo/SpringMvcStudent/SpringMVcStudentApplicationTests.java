package com.demo.SpringMvcStudent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMVcStudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
