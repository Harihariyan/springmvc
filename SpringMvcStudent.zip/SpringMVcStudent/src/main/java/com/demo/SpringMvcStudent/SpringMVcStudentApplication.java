package com.demo.SpringMvcStudent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMVcStudentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMVcStudentApplication.class, args);
	}

}
