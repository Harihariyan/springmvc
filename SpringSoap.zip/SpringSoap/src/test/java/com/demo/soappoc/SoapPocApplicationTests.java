package com.demo.soappoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapPocApplicationTests {

	@Test
	void contextLoads() {
	}

}
